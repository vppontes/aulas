const frm = document.querySelector("form")
const respNome = document.querySelector("span")
const respLista = document.querySelector("pre")


const pedidos = [] //declara um vetor global

frm.addEventListener("submit", (e) => {
    e.preventDefault() 
    const nome = frm.inPedido.value //obtém o nome do paciente
    pedidos.push(nome) //adiciona nome ao final do vetor
    let lista = "" //string para concatenar pacientes
    //for "tradicional" (incial em 0, enquanto menor que tamanho do array)
    for (let i = 0; i < pedidos.length; i++) {
        lista += `${i + 1}. ${pedidos[i]}\n`
    }
    respLista.innerText = lista //exibe a lista de pacientes na página
    frm.inPedido.value = "" //limpa conteúdo do campo do formulário
    frm.inPedido.focus() //posiciona o cursor no campo
})

// Adiciona um "ouvinte" para o evento click no btUrgencia que está no form
frm.btPreferencia.addEventListener("click", () => {
    //verifica se as validações do form estão ok (no caso, paciente is required)
    if (!frm.checkValidity()) {
        alert("Informe o nome do paciente a ser atendido em caráter de urgência")
        frm.inPedido.focus() //posiciona o cursor no campo
        return //retorna ao form
    }
    const nome = frm.inPedido.value //obtém nome do paciente
    pedidos.unshift(nome) //adiciona paciente ao início do vetor
    let lista = "" //string para concatenar pacientes
    //forEach aplicado sobre o array pacientes
    pedidos.forEach((pedido, i) => (lista += `${i + 1}. ${pedido}\n`))
    respLista.innerText = lista //exibe a lista de pacientes na página
    frm.inPedido.value = "" //limpa conteúdo do campo de formulário
    frm.inPedido.focus() //posiciona o cursor no campo
})

frm.btAtender.addEventListener("click", () => {
    if (pedidos.length == 0) {
        alert("Não há pacientes na lista de espera")
        frm.inPedido.focus()
        return
    }
    const atender = pedidos.shift() //remove do início da fila (e obtém nome)
    respNome.innerText = atender //exibe o nome do paciente em atendimento
    let lista = "" //string para concatenar pacientes
    pedidos.forEach((pedido, i) => (lista += `${i + 1}. ${pedido}\n`))
    respLista.innerText = lista //exibe a lista de pacientes na página
})

frm.btCancelar.addEventListener("click", () => {
    let nome = Number(frm.inPedido.value)
    pedidos.splice(nome - 1, 1)
    
    let lista = "" 
    for (let i = 0; i < pedidos.length; i++) {
        lista += `${i + 1}. ${pedidos[i]}\n`
    }
    respLista.innerText = lista //exibe a lista de pacientes na página
    frm.inPedido.value = "" //limpa conteúdo do campo do formulário
    frm.inPedido.focus() //posiciona o cursor no campo
} )